#!/bin/bash
# SM Reader - _run_server.sh
# last modified (utc): 2026-10-07-01-16-00
# instructions: on modify, update string.
# Local test server. The port is set in ONE place. A service worker, its cache and the app's data belong to one address
# (host + port), so SM Reader has its own port and cannot be mixed up with other projects served on 8000.
PORT=7777

echo -ne "\033]0;server: sm reader\007"
echo "local ip: http://$(ip route get 1.1.1.1 | awk '{print $7; exit}'):$PORT"
echo "or: http://localhost:$PORT"
python3 -m http.server $PORT
