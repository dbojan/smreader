<!-- SM Reader - install.md -->
<!-- last modified (utc): 2026-10-09-11-30-26 -->
<!-- instructions: on modify, update string. -->
# SM Reader: Install & Update

Static app, no build step. Never commit books or `not_needed_after_editing/` backups.

## Host on GitHub Pages (no own server)

1. Create repo `smreader`.
2. In the repo: Add file → Upload files, drag this folder's contents
   (`index.html`, `sw.js`, `manifest.json`, `css/`, `js/`, `fonts/`, `icons/`, `dict/`).
   Web upload limit is 25 MB per file; the largest file is `dict/oewn-2025.json.gz` (4.6 MB).
3. Repo Settings → Pages → Deploy from branch → `main`, folder `/`.
4. Open `https://<you>.github.io/smreader/` once (online), then browser menu →
   "Install SM Reader" / "Add to Home screen" (pins the icon). After that it opens
   without internet; books, bookmarks, settings and the dictionary are stored on the device.
   - Settings → App → "Keep app in cache" (default Yes) keeps the app's files for offline use.
     "Remove offline copy" deletes them; your data stays.
   - The dictionary is imported once in the background at the first start (Settings →
     Dictionary), which needs the internet once.
   - All Pages sites of one account share the address `<you>.github.io`. SM Reader only touches
     its own service worker (its folder) and its own caches (`sm-reader-…`), so other apps there are safe.

## Local testing

`./_run_server.sh` (or `python3 -m http.server 7777` in this folder), then open
`http://localhost:7777`. The port is set in one place at the top of `_run_server.sh`.

- `file://` does not work (ES modules + worker need http/https).
- By default (Keep app in cache = Yes) the app saves its own files at the first visit: open
  `http://localhost:7777` once, then the server can be stopped and the app still opens from that
  address in the same browser. Chrome and Edge also offer "Install app" there (Firefox on a computer
  cannot install web apps, but the offline copy works).
- While developing, a new version is downloaded in the background and Settings → App shows
  "App update ready" (Reload). To always get the files straight from the server, set Keep app in
  cache to No (saved per address, so `localhost:7777` can differ from the site).
- From a phone on the LAN (`http://<pc-ip>:7777`) the app works, but plain http is not a
  secure context: no service worker (no offline, no install), no screen wake lock, no
  clipboard API. Use https hosting for those.
- Every address (host + port) is its own site: library, settings and dictionary are separate
  per address. Move data with Settings → Backup → Export / Import (the dictionary is not in
  the backup; it imports again by itself).

## Update the app

Upload overwriting files (same paths); Pages redeploys in ~a minute.
Each patch changes `CACHE` in `sw.js` and `APP_VERSION` in `js/app.js` (the same value, the
patch's UTC stamp). With "Keep app in cache" on, the browser finds the new `sw.js` on the next
visit (or when the app is shown again, checked at most once an hour), installs it in the
background, and Settings → App shows "App update ready" with a Reload button (a plain reload).
Settings → App → "Load fresh app" (update check, drop caches, unregister, reload; needs the
internet) is the heavy fallback for a copy that is really stuck. Without a stored copy
(Keep app in cache = No) the next page load simply gets the newest files.

## Update the dictionary

New file: `python3 oewn_trim.py english-wordnet-XXXX-json.zip` writes a sorted `oewn-XXXX.json.gz`;
put it into `dict/` (same name as before, or change `SWITCH_DICT_BUNDLED_FILE`). In `js/app.js`
keep the id `oewn-2025` and raise `BUNDLED_DICT.build` by one (also `name`, the attribution line
in `index.html`, and `dict/LICENSE-oewn.txt` if needed). With "Import dictionary at: Start" it
updates itself at the next start; otherwise Settings → Dictionary shows "update available".
The script also stores the part of speech of each irregular form, so `was` shows the verb `be`
only; run it with the 2025 zip once (`python3 oewn_trim.py english-wordnet-2025-json.zip dict/oewn-2025.json.gz`)
and upload the new file together with the app (build 3 is already in the code).

## Address already in use / old version after stopping the server

A port stays bound only while a server process lives. "Address already in use" means another
process holds it: `lsof -i :7777` (or `ss -tlnp | grep 7777`) → `kill <PID>` → restart, or pick
another port in `_run_server.sh`.

If the page still opens after the server is stopped, or shows an old version, it is not the
port: the browser keeps a service worker and cached files for that address. Fix: Settings →
App → "Remove offline copy" (or "Load fresh app" while online). Firefox:
`about:debugging#/runtime/this-firefox` → Service Workers → Unregister. Chrome: DevTools →
Application → Service Workers → Unregister (clearing all site data also deletes the library).
That is the offline copy doing its job (Keep app in cache = Yes is the default). To start from
the server's files again use "Remove offline copy", or set Keep app in cache to No.
