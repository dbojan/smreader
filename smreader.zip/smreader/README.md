<!-- SM Reader - README.md -->
<!-- last modified (utc): 2026-10-07-12-54-28 -->
<!-- instructions: on modify, update string. -->
# SM Reader — v1 (milestone 1)

> Status note (2026-10-07): this README describes milestone 1. Later additions (bookmarks and
> notes, dictionary, hold-to-select, offline settings, update notices) are recorded in `spec.md`
> (section 15); install, update and port notes are in `install.md`.

A simple, book-like EPUB reader in the style of Microsoft Reader. See `spec.md`
(from our conversation) for the full plan; this is a first working version.

## What's here

- EPUB import (drag files onto the page, or the Import button) — stored in
  IndexedDB, nothing leaves your device.
- MS Reader-style page: single centered page on a dark surround, sized to the
  proportions measured from the reference screenshots (~88% of viewport
  height, ~3:4 page ratio) — both now adjustable in Settings → Page geometry.
- **Page turning:** click the left/right half of the page (text or margin),
  the footer arrows, arrow keys, Page Up/Down, or scroll up/down. A click-
  and-drag to select text is detected and does *not* turn the page.
- **Side (red) menu:** shown by default. A click anywhere (page or black
  surround) that finds an open "Go to" dropdown closes *that* first; if
  there's no dropdown open but the sidebar is showing, that click hides the
  sidebar instead. Only once both are already dismissed does a click turn
  the page. Click the top-left hot corner (away from the page) to bring the
  sidebar back — or use "Toggle menu" in the Go to menu, which now shows the
  sidebar again if it was already hidden. Clicking the book title at the top
  of the page opens the same "Go to" menu as the sidebar button, and (now
  fixed) it opens correctly and stays interactive even from the Settings or
  Table of Contents screens.
- **Go to menu:** Table of Contents, Most recent page, Begin reading,
  Furthest read, Cover Image, Go to position…, Full screen (F11), Toggle
  menu.
- **Full screen:** press `F`, or use the Go to menu; `Esc` exits. Optional
  setting (Settings → Show/hide → "Hiding the side menu also goes full
  screen") links the two, so hiding the menu enters full screen and showing
  it again exits.
- Any layout change that can shift how much text fits on a page — window
  resize, entering/exiting full screen, or the sidebar appearing/
  disappearing (which changes the page's available width) — is watched
  generically, and the reader snaps back to the exact spot it was at just
  before the change, once the new layout settles. (Fixed properly this
  time: the first attempt read the "before" position too late, after the
  paginator had already drifted it — it now keeps a continuously-updated
  last-known-good position instead, so there's no race.)
- **Scroll to turn pages** now works over the whole app, not just inside the
  rendered text — page padding, header/footer area, the dark surround.
- When the top menu and the whole bottom line (arrows + position) are both
  fully hidden, the page's top/bottom margin shrinks to match its left/
  right margin, instead of staying reserved at header/footer size — governed
  by another testable flag, see below.
- Fonts: Jost (bundled, Futura-like), two system fonts, a field to type any
  installed font name, and a file upload for your own font.
- Font size: a row of sensible sizes (12–32px) plus a custom-size field. The
  page title and footer scale with it.
- Themes: white / cream / night — now correctly applied to the actual book
  text background/color, not just the page chrome around it.
- Line spacing slider; page size and frame (margin) size sliders.
- **Show/hide settings** for the top menu, bottom arrows, and position
  display: Always, With side menu, or Never.
- Position: saved automatically as an EPUB CFI whenever you turn a page, and
  restored when you reopen the book. Percentage shown in the footer, between
  the two page-turn arrows. "Go to → Go to position…" jumps to a typed
  percentage.
- **Export/Import (Settings → Backup):** save your settings, reading
  positions, and library metadata as one JSON file — optionally including
  the book files themselves — and load it back on another device/browser.
- Installable as a PWA (manifest with icons + service worker). Served over https (GitHub Pages)
  it opens offline after one visit (Settings → App → Keep app in cache); on plain http
  (a phone on the LAN) there is no service worker.

## A note on two experimental flags

Both live on `window.SM_READER_FLAGS` and can be flipped live in devtools to
compare the feel — tell me which you settle on and I'll hard-code it and
drop the flag.

- `SWITCH_CLICK_LEFT_OR_RIGHT_ON_BLACK_SCREEN_WHEN_NO_RED_MENU_PRESENT_GOES_TO_PREV_NEXT_PAGE`
  (default `true`): when the side menu is hidden, clicking the dark surround
  (not just the page) also turns pages, left/right half of the screen.
- `SWITCH_HIDE_TOP_BOOK_MENU_AND_POSITION_AT_BOTTOM_MAKES_TOP_AND_BOTTOM_MARGINS_SAME_SIZE_AS_LEFT_AND_RIGHT_MARGINS`
  (default `true`): described just above.


## Try it locally

Browsers block ES module imports over `file://`, so it needs a tiny local
server — no build step, no install beyond this:

```
cd site
python3 -m http.server 7777
```

Then open `http://localhost:7777/` in Firefox or Chrome (`./_run_server.sh` does the same;
the port is set at its top).

## Put it on GitHub Pages

1. Create a public repo named `smreader`.
2. Upload everything in this `site/` folder to the repo root (so
   `index.html` sits at the repo root, not inside a subfolder).
3. Settings → Pages → deploy from the `main` branch, root folder.
4. It'll be live at `https://<your-username>.github.io/smreader/`.

All paths in the app are relative, so it works fine under that `/smreader/`
subpath.

## What's deliberately left out of this first version

Per the spec's milestones, these come later: advanced page-geometry
controls (scale, width/height presets, the measured "Reader classic"
preset), bookmarks/highlights/notes, export/import and link/QR position
sharing, and XMPP sync. The current position-saving (CFI, auto-resume,
percentage) already covers the "remembered position" piece for a single
device.

Only Jost is bundled as a real font file right now (it was the one you
specifically wanted, as a Futura substitute). The other "bundled" options in
the spec (Outfit, Questrial, League Spartan, Literata, Atkinson Hyperlegible)
aren't wired in yet — the font-picker code is written so adding one is just
dropping a `.ttf`/`.woff2` into `fonts/`, adding an `@font-face` rule in
`css/style.css`, and one entry in the `BUNDLED_FONTS` list in `js/app.js`.

## Known rough edges / not yet fixed

- Book "fingerprint" for matching a book across devices/imports is a
  SHA-256 of the file's first 1MB plus its size — fine for telling your own
  books apart, not cryptographically rigorous.
- Icons: `icons/icon-192.png` and `icons/icon-512.png` (the 512 file doubles as the maskable icon); source `sm-icon.svg` is not part of the app.
- The gap between the page title and the book text is a fixed proportion
  (1.3× the title's own font size) — not yet a separate settings control,
  though it's an easy one to add if you want it exposed.
- The dark "annotation flag" markers and the Screen/Voice settings pages
  from MS Reader weren't ported — they weren't in the v1 feature list.
- Mobile EPUB import: the file-type filter was loosened to accept files
  whose name doesn't end in `.epub` but whose MIME type looks right (common
  on some mobile pickers/cloud providers), and failures now show an alert
  instead of failing silently. If it's still not picking up files on your
  tablet/phone, tell me what browser/OS and I'll dig further — this one I
  couldn't fully verify without a real device.
- Show/hide settings for the header/arrows/position now preserve their
  layout space (using `visibility`, not `display`) so hiding them doesn't
  collapse the page's top/bottom margin.
