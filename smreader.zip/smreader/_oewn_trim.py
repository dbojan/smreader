#!/usr/bin/env python3
# SM Reader - oewn_trim.py
# last modified (utc): 2026-10-07-12-54-28
# instructions: on modify, update string.
"""
Trim the Open English WordNet JSON release into one small dictionary file
(JSON Lines, SM Reader dictionary format "smr-dict", version 2).

Usage:
    python oewn_trim.py english-wordnet-2025-json.zip
        -> writes oewn-2025.json.gz next to the input (gzipped)
    python oewn_trim.py english-wordnet-2025-json.zip my-dict.json
        (a name ending in .gz is gzipped, any other name is written as plain text)
    python oewn_trim.py IN.zip --name "Open English WordNet 2025"

Only the standard library is used. The zip is read directly (no unzip needed).

Input (from en-word.net/downloads, "english-wordnet-2025-json.zip"):
    entries-*.json   headword -> part of speech -> {form, pronunciation, sense[]}
    <category>.json  synset id -> {definition[], example[], ...}  (noun.*, verb.*, adj.*, adv.*)
    frames.json      ignored

Output (JSON Lines: one JSON value per line, UTF-8, "\n" line ends):
    line 1, header:
      {"format":"smr-dict","version":2,"name":"...","language":"en","license":"CC BY 4.0",
       "source":"https://en-word.net/","entries":N,"forms":M}      (on one line in the file)
    then N entry lines, sorted by word:
      {"w":"sling","g":[["n",["definition", ...]],["v",[...]]]}
    then M form lines, sorted by form:
      {"f":"slung","h":["sling"],"p":["v"]}
    - w is the lowercase headword; g is a list of groups [pos, definitions]
      (pos: n noun, v verb, a adjective, r adverb). A homograph (bass, n-1) is its own group.
    - a group gets a third item, the original spelling, only when it differs from w
      (for example ["n", [...], "Alice"]), so capitalized words are not mislabeled.
    - f is an irregular inflected form, h its headword(s).
    - p (since 2026-10-07; the header has "form_pos":true) lists, for each headword in h, the parts of speech under
      which WordNet lists the form, as one string of letters ("v", "nv"). The app then shows only those senses
      (was -> be: the verb, not the noun beryllium). A file without p (older files) shows all senses.
    Dropped: examples, pronunciations, all relations, ids, usage frames.
"""
import argparse
import gzip
import json
import os
import re
import sys
import zipfile


def read_json(zf, name):
    with zf.open(name) as fh:
        return json.loads(fh.read().decode("utf-8"))


def main():
    ap = argparse.ArgumentParser(description="Trim OEWN JSON zip into one small dictionary file (JSON Lines).")
    ap.add_argument("zip_in", help="english-wordnet-XXXX-json.zip")
    ap.add_argument("out", nargs="?", help="output file (optional; default: oewn-2025.json.gz next to the input); a name ending in .gz is gzipped")
    ap.add_argument("--name", default="Open English WordNet 2025", help="dictionary name stored in the file")
    args = ap.parse_args()

    out_path = args.out or os.path.join(os.path.dirname(os.path.abspath(args.zip_in)), "oewn-2025.json.gz")
    zf = zipfile.ZipFile(args.zip_in)
    names = [n for n in zf.namelist() if n.lower().endswith(".json")]
    entry_files = sorted(n for n in names if re.search(r"(^|/)entries-[^/]*\.json$", n))
    synset_files = sorted(n for n in names if n not in entry_files and not n.endswith("frames.json"))
    if not entry_files or not synset_files:
        sys.exit("error: no entries-*.json or synset files found in the zip")

    # 1. synset id -> list of definition strings
    defs = {}
    for n in synset_files:
        for sid, v in read_json(zf, n).items():
            d = v.get("definition") if isinstance(v, dict) else None
            if d:
                defs[sid] = [x.strip() for x in d if isinstance(x, str) and x.strip()]

    # 2. entries. Exact-lowercase headwords go first so they lead when
    #    "Polish" and "polish" merge under one key.
    raw = {}
    for n in entry_files:
        raw.update(read_json(zf, n))

    entries, forms = {}, {}
    missing = 0
    for word in sorted(raw, key=lambda w: (w != w.lower(), w)):
        key = word.lower()
        for pos_key, e in raw[word].items():
            pos = pos_key.split("-")[0]
            if pos == "s":  # satellite adjective -> adjective
                pos = "a"
            seen, out_defs = set(), []
            for s in e.get("sense", []):
                sid = s.get("synset")
                if sid in seen:
                    continue
                seen.add(sid)
                if sid not in defs:
                    missing += 1
                    continue
                out_defs.extend(defs[sid])
            if out_defs:
                group = [pos, out_defs]
                if word != key:
                    group.append(word)
                entries.setdefault(key, []).append(group)
            for f in e.get("form", []):
                fk = f.lower()
                if fk != key:
                    forms.setdefault(fk, {}).setdefault(key, set()).add(pos)  # headword -> parts of speech

    def line(obj):
        return json.dumps(obj, ensure_ascii=False, separators=(",", ":"))

    header = {
        "format": "smr-dict",
        "version": 2,
        "name": args.name,
        "language": "en",
        "license": "CC BY 4.0",
        "source": "https://en-word.net/",
        "entries": len(entries),
        "forms": len(forms),
        "form_pos": True,
    }
    lines = [line(header)]
    lines.extend(line({"w": k, "g": entries[k]}) for k in sorted(entries))
    def form_line(k):
        heads = list(forms[k])
        return line({"f": k, "h": heads, "p": ["".join(sorted(forms[k][h])) for h in heads]})
    lines.extend(form_line(k) for k in sorted(forms))
    data = ("\n".join(lines) + "\n").encode("utf-8")
    if out_path.lower().endswith(".gz"):
        data = gzip.compress(data, compresslevel=9, mtime=0)
    with open(out_path, "wb") as fh:
        fh.write(data)

    print("headwords: %d  irregular forms: %d  senses without definition: %d" % (len(entries), len(forms), missing))
    print("wrote %s (%.1f MB)" % (out_path, len(data) / 1e6))


if __name__ == "__main__":
    main()
